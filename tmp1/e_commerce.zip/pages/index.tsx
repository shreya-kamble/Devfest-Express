
import { Fragment, useEffect, useState } from "react";
import { getEntry } from "../contentstack-sdk";

import {
  CallToAction,
  Faq,
  Feature,
  Footer,
  Header,
  Product,
} from "cspage-storybook";

const componentMapping: any = {
  header_c001: Header.Header_C001,
  header_c002: Header.Header_C002,
  header_c003: Header.Header_C003,
  footer_c001: Footer.Footer_C001,
  footer_c002: Footer.Footer_C002,
  footer_c003: Footer.Footer_C003,
  faq_c001: Faq.Faq_C001,
  faq_c002: Faq.Faq_C002,
  faq_c003: Faq.Faq_C003,
  feature_c001: Feature.Feature_C001,
  feature_c002: Feature.Feature_C002,
  calltoaction_c001: CallToAction.CallToAction_C001,
  calltoaction_c002: CallToAction.CallToAction_C002,
  calltoaction_c003: CallToAction.CallToAction_C003,
  calltoaction_c004: CallToAction.CallToAction_C004,
  product_c001: Product.Product_C001,
  product_c002: Product.Product_C002,
};

export default function Home (props:any) {

  const [entry, setEntry]:any = useState(null)
    async function fetchData() {
    try {
      const entryRes:any = await getEntry({
        contentTypeUid: "home",
        referenceFieldPath: [],
        jsonRtePath: []
      });
      if (!entryRes) throw new Error('Status code 404');
      setEntry(entryRes[0][0]);
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    fetchData()
  }, []);

  if(!entry) {
    return <div></div>
  }

  return (
    <Fragment>
      {Object.keys(entry).map((field, index) => {
        if(field.indexOf('_c00') > -1) {
          let Component = componentMapping[field];
          const componentProps = entry[field];
          return (
            <div key={index}>
              <Component {...componentProps} />
            </div>
          )
        }
      })}
    </Fragment>
  )
}